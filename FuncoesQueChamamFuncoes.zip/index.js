/** CRIE UM ARRAY DE OBJETO => PESSOAS
 * COM OS SEGUINTES ATRIBUTOS : NOME/SOBRENOME
 * CRIE UMA FUNÇÃO QUE ITERE SOBRE O ARRAY
 * E RETIRE NOMES E SOBRENOMES
 * CRIE UMA VARIÁVEL COM O CONTEÚDO:
 *       -> const emailBase = "@escola.pr.gov.br"
 * A PARTIR DESSES DADOS FORME UM @escola COM
 * NOME.SOBRE+EMAILBASE
 * EXECUTE A FUNÇÃO
 */
const pessoas = []
// CRIAR EMAIL BASE
const emailBase = "@escola.pr.gov.br";

// FUNÇÃO DE CONSTRUÇÃO E IMPRESSÃO
function gerarEmail() {
  if (pessoas.length == 0) {
    console.log("Nenhum aluno cadastrado");
  } else{
    for (pessoa of pessoas) {
      const nome = pessoa.nome;
      const sobrenome = pessoa.sobrenome;
      const email = `${nome}.${sobrenome}${emailBase}`;
      console.log(email);
    }
  }
}
// FUNÇÃO DE CADASTRO
function cadastrarAluno(nome, sobrenome) {
  pessoas.push({ nome: nome, sobrenome: sobrenome});
}
// CADASTRE 5 ALUNOS
cadastrarAluno("Gabriely", "Cristina");
cadastrarAluno("Matheus", "Artur");
cadastrarAluno("Maria", "Eduarda");
cadastrarAluno("Ana", "Beatriz")
cadastrarAluno("Denise", "Cristina")

gerarEmail(); // CONVERTAM O CÓDIGO ACIMA PARA UMA FUNÇÃO INVOCÁVEL
// E EXECUTÁVEL

